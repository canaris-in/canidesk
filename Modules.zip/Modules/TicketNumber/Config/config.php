<?php

return [
    'name' => 'TicketNumber',
    'prefix' => env('TICKETNUMBER_PREFIX', '[#'),
    'suffix' => env('TICKETNUMBER_SUFFIX', '] '),
];
