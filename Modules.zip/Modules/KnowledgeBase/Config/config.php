<?php

return [
    'name' => 'KnowledgeBase'
];
