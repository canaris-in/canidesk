<?php

return [
    'name' => 'DarkMode'
];
