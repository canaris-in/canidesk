<li>
    <label id="dm-switch" data-toggle="tooltip" data-placement="right" title="{{ __('Dark Mode') }}"><input name="darkmode" type="checkbox" @if ($on) checked="checked" @endif><span class="dm-switch-inner"></span></label>
</li>