<?php

return [
    'name' => 'Crm',
    'conv_fields' => env('CRM_CONV_FIELDS', ''),
];
