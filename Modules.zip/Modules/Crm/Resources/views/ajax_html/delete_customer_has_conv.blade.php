<div>
	<div class="text-center">
		<div class="text-larger margin-top-10"><div class="alert alert-warning">{{ __("This customer has conversations. In order to delete the customer you need to completely delete all customer's conversations first.") }}</div></div>
		<div class="form-group margin-top">
			<button class="btn btn-default" data-dismiss="modal">OK</button>
		</div>
	</div>
</div>