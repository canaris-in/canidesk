<div class="dropdown">
	<button class="btn btn-default" data-toggle="dropdown"><i class="glyphicon glyphicon-list-alt"></i> <span class="caret"></span></button>
	<ul class="dropdown-menu dm-scrollable">
		<li>
			<div class="input-group">
				<input type="text" class="form-control">
				<span class="input-group-btn">
					<button class="btn btn-default" type="button"><i class="glyphicon glyphicon-floppy-disk"></i></button>
				</span>
		    </div>
		</li>
		<li><i class="glyphicon glyphicon-trash rpt-view-delete" data-toggle="tooltip" title="{{ __('Delete') }}"></i><a href="">Test</a></li>
	</ul>
</div>