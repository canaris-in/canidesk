{{-- Does not work if in build.js --}}
<script src="{{ asset(\Module::getPublicPath(REPORTS_MODULE).'/js/highcharts.js') }}"></script>